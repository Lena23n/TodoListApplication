RAD.model('groupItem', Parse.Object.extend('Group',{

}), false);